import React from 'react'

export default function PlayGame() {
  return (
    <div>
      <p>Game Started!!!</p>
    </div>
  )
}
